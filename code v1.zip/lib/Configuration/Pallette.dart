import 'package:flutter/material.dart';

const Color mainColor = Color(0xff31326f);
const Color sColor1 = Color(0xff9ddfd3);
const Color sColor2 = Color(0xffdbf6e9);
const Color sColor3 = Color(0xffffc93c);
