import 'dart:typed_data';
import 'dart:ui';
import 'package:flutter/services.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:get/get.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:locateme/Models/ServiceProvider.dart';
import 'package:locateme/Services/FirestoreServices.dart';
import 'package:sliding_up_panel/sliding_up_panel.dart';
// import 'package:flutter/services.dart' show rootBundle;

class RegularUserController extends GetxController {
  FirestoreService _firestoreService = FirestoreService();
  RxSet<Marker> markers = RxSet<Marker>();
  RxList<ServiceProvider> serviceProviders = RxList<ServiceProvider>();

  PanelController panelController = PanelController();
  Rx<ServiceProvider> selectedProvider = Rx<ServiceProvider>(null);
  GoogleMapController mapController;

  // RxnString lightStyle = RxnString();
  // RxnString darkStyle = RxnString();
  // RxnString selectedMapStyle = RxnString();

  //fab data
  final double _initFabHeight = 120; // Get.height * 0.15;
  final double panelHeightOpen = Get.height * 0.75;
  RxDouble fabHeight = RxDouble(0);
  @override
  void onInit() {
    super.onInit();
    getServices();
    fabHeight.value = _initFabHeight;
    // rootBundle.loadString('assets/mapStyles/lightMap.txt').then((string) {
    //   lightStyle.value = string;
    // });
    // rootBundle.loadString('assets/mapStyles/darkMap.txt').then((string) {
    //   lightStyle.value = string;
    // });
  }

  getServices() async {
    List<DocumentSnapshot> docs =
        await _firestoreService.getServicesProviders();
    for (int i = 0; i < docs.length; i++) {
      ServiceProvider serviceProvider =
          ServiceProvider.fromJson(docs[i].data());
      serviceProviders.add(serviceProvider);
      _addMarker(serviceProvider);
    }
  }

  Future<Uint8List> _getBytesFromAsset(String path, int width) async {
    ByteData data = await rootBundle.load(path);
    Codec codec = await instantiateImageCodec(data.buffer.asUint8List(),
        targetWidth: width);
    FrameInfo fi = await codec.getNextFrame();
    return (await fi.image.toByteData(format: ImageByteFormat.png))
        .buffer
        .asUint8List();
  }

  _addMarker(ServiceProvider serviceProvider) async {
    double lat = double.parse(serviceProvider.latitude);
    double long = double.parse(serviceProvider.longitude);

    final MarkerId markerId = MarkerId(serviceProvider.fullName);
    final Uint8List markerIcon = await _getBytesFromAsset(
        'assets/icons/${serviceProvider.profession.toLowerCase()}.png', 100);

    // creating a new MARKER
    final Marker marker = Marker(
        icon: BitmapDescriptor.fromBytes(markerIcon),
        markerId: markerId,
        position: LatLng(lat, long),
        onTap: () {
          selectedProvider.value = serviceProvider;
          update();
          panelController.open();
        });
    markers.add(marker);
  }

  changeFabHeight(double pos) {
    if (panelController.isPanelClosed) {
      fabHeight.value = _initFabHeight;
    } else {
      fabHeight.value = pos * (panelHeightOpen - 10) + _initFabHeight;
    }
  }
}
