import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:geolocator/geolocator.dart';
import 'package:get/get.dart';
import 'package:locateme/Configuration/Pallette.dart';
import 'package:locateme/Services/ThemServices.dart';
import 'package:locateme/Widgets/CustomDrawerWidget.dart';
import 'package:permission_handler/permission_handler.dart';

class RegUserAppController extends GetxController
    with SingleGetTickerProviderMixin {
  final AdvancedDrawerController drawerController = AdvancedDrawerController();
  AnimationController controller;

  RxInt selectedPage = RxInt(0);

  RxBool expanded = RxBool(true);
  @override
  void onInit() {
    super.onInit();
    controller = AnimationController(
        duration: Duration(milliseconds: 400),
        reverseDuration: Duration(milliseconds: 400),
        vsync: this);

    checkPermissions();
  }

  @override
  void onClose() {
    super.onClose();
    controller.dispose();
    drawerController.dispose();
  }

  changePage(int newIndex) {
    selectedPage.value = newIndex;
    update();
    handleMenuButtonPressed();
  }

  void handleMenuButtonPressed() {
    expanded.value ? controller.forward() : controller.reverse();

    if (expanded.value) {
      SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle.dark.copyWith(
          statusBarColor: mainColor, // Color for Android
          statusBarBrightness:
              Brightness.light // Dark == white status bar -- for IOS.
          ));
    } else {
      SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle.dark.copyWith(
          statusBarColor: ThemeService().isDarkMode()
              ? Colors.black
              : Colors.white, // Color for Android

          statusBarBrightness:
              Brightness.dark // Dark == white status bar -- for IOS.
          ));
    }
    expanded.value = !expanded.value;
    drawerController.toggleDrawer();
  }

  checkPermissions() async {
    var status = await Permission.location.status;

    bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (serviceEnabled) {
      if (!status.isGranted) {
        print("permission not granted");
        Permission.location.request();
        // We didn't ask for permission yet or the permission has been denied before but not permanently.
      }
    } else {
      Get.snackbar(
        "Location Services are Disabled",
        "Enable them to use location features",
        snackPosition: SnackPosition.TOP,
        duration: Duration(seconds: 3),
        overlayColor: Colors.white.withOpacity(0.8),
        overlayBlur: 1,
        // borderRadius: 36,
        forwardAnimationCurve: Curves.easeInOutBack,
        reverseAnimationCurve: Curves.easeInCubic,
        icon: Icon(
          Icons.warning,
          color: sColor3,
        ),
        shouldIconPulse: true,
        snackStyle: SnackStyle.FLOATING,
      );
    }
  }
}
