import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:get/get.dart';
import 'package:locateme/Configuration/FontStyles.dart';
import 'package:locateme/Configuration/Pallette.dart';
import 'package:locateme/Controllers/RegularUserController.dart';
import 'package:locateme/Models/ServiceProvider.dart';
import 'package:url_launcher/url_launcher.dart';

class RegUserPanelWidget extends StatelessWidget {
  final ScrollController sc;

  RegUserPanelWidget({this.sc});

  final RegularUserController controller = Get.put(RegularUserController());

  @override
  Widget build(BuildContext context) {
    ServiceProvider serviceProvider = controller.selectedProvider.value;
    return Obx(() => MediaQuery.removePadding(
          context: context,
          removeTop: true,
          child: Container(
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.only(
                topRight: Radius.circular(48),
                topLeft: Radius.circular(48),
              ),
            ),
            child: controller.selectedProvider.value != null
                ? ListView(
                    children: [
                      SizedBox(
                        height: 12.0,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: <Widget>[
                          Container(
                            width: 60,
                            height: 10,
                            decoration: BoxDecoration(
                              color: Colors.grey[400],
                              borderRadius: BorderRadius.all(
                                Radius.circular(12.0),
                              ),
                            ),
                          ),
                        ],
                      ),
                      SizedBox(
                        height: 12.0,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          IconButton(
                            icon: Icon(
                              FontAwesomeIcons.phoneAlt,
                              size: 36,
                              color: sColor3,
                            ),
                            onPressed: () {
                              launch("tel://${serviceProvider.phoneNumber}");
                            },
                          ),
                          Container(
                            child: Center(
                              child: Container(
                                height: Get.height * 0.20,
                                width: Get.height * 0.20,
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(36),
                                  color: Colors.grey[200],
                                  image: serviceProvider.photoUrl == "none"
                                      ? null
                                      : DecorationImage(
                                          image: Image.network(
                                                  serviceProvider.photoUrl)
                                              .image,
                                          fit: BoxFit.cover),
                                ),
                                child: serviceProvider.photoUrl == "none"
                                    ? Center(
                                        child: Text(serviceProvider.fullName[0]
                                            .toLowerCase()),
                                      )
                                    : null,
                              ),
                            ),
                          ),
                          IconButton(
                            icon: Icon(
                              FontAwesomeIcons.whatsapp,
                              size: 36,
                              color: Colors.green,
                            ),
                            onPressed: () {
                              var whatsappUrl =
                                  "whatsapp://send?phone=${serviceProvider.phoneNumber}";
                              launch(whatsappUrl);
                            },
                          ),
                        ],
                      ),
                      SizedBox(
                        height: 12.0,
                      ),
                      Padding(
                        padding: const EdgeInsets.fromLTRB(32, 0, 32, 0),
                        child: Container(
                          height: Get.height * 0.13,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(25),
                            color: sColor3,
                          ),
                          child: Center(
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Column(
                                  // mainAxisSize: MainAxisSize.min,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Padding(
                                      padding: const EdgeInsets.only(left: 16),
                                      child: Align(
                                        child: Text(
                                          serviceProvider.profession,
                                          style: mainStyle(
                                            fontSize: 20,
                                            fontColor: Colors.blueGrey,
                                          ),
                                          textAlign: TextAlign.left,
                                        ),
                                        alignment: Alignment.centerLeft,
                                      ),
                                    ),
                                    SizedBox(
                                      height: 10.0,
                                    ),
                                    Padding(
                                      padding: const EdgeInsets.only(left: 16),
                                      child: Text(
                                        serviceProvider
                                            .fullName.capitalizeFirst,
                                        style: mainStyle(fontSize: 36),
                                      ),
                                    ),
                                  ],
                                ),
                                Container(
                                  margin: EdgeInsets.all(8),
                                  height: Get.height * 0.1,
                                  width: Get.height * 0.1,
                                  decoration: BoxDecoration(
                                    color: Colors.white,
                                    borderRadius: BorderRadius.circular(16),
                                    image: DecorationImage(
                                        image: Image.asset(
                                      "assets/icons/${serviceProvider.profession.toLowerCase()}.png",
                                    ).image),
                                  ),
                                )
                              ],
                            ),
                          ),
                        ),
                      ),
                      SizedBox(
                        height: 12.0,
                      ),
                      Padding(
                        padding: const EdgeInsets.fromLTRB(32, 0, 32, 0),
                        child: Container(
                          margin: const EdgeInsets.all(8),
                          padding: const EdgeInsets.all(8),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(16),
                            color: sColor1,
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                "Service Provider Bio",
                                style: mainStyle(
                                  fontSize: 30,
                                  fontColor: mainColor,
                                ),
                                textAlign: TextAlign.start,
                              ),
                              Wrap(
                                children: [
                                  Text(
                                    serviceProvider.bio,
                                    style: montserratStyle(
                                      fontSize: 18,
                                      fontColor: Colors.white,
                                    ),
                                  )
                                ],
                              )
                            ],
                          ),
                        ),
                      )
                    ],
                  )
                : Center(
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [Text("No provider is Selected")],
                    ),
                  ),
          ),
        ));
  }
}
// ListView(
//                     physics: BouncingScrollPhysics(),
//                     // controller: sc,
//                     children: <Widget>[
//                       SizedBox(
//                         height: 12.0,
//                       ),
//                       Row(
//                         mainAxisAlignment: MainAxisAlignment.center,
//                         children: <Widget>[
//                           Container(
//                             width: 60,
//                             height: 10,
//                             decoration: BoxDecoration(
//                                 color: Colors.grey[400],
//                                 borderRadius:
//                                     BorderRadius.all(Radius.circular(12.0))),
//                           ),
//                         ],
//                       ),
//                       Container(
//                         margin: EdgeInsets.all(16),
//                         height: Get.height * 0.15,
//                         width: Get.height * 0.15,
//                         decoration: BoxDecoration(
//                           color: mainColor,
//                           shape: BoxShape.circle,
//                           image: DecorationImage(
//                             image: controller.selectedProvider.value.photoUrl ==
//                                     "none"
//                                 ? null
//                                 : Image.network(
//                                     controller.selectedProvider.value.photoUrl,
//                                   ).image,
//                             fit: BoxFit.contain,
//                           ),
//                         ),
//                       ),
//                       Padding(
//                         padding: const EdgeInsets.only(
//                           left: 16,
//                           right: 16,
//                           bottom: 16,
//                         ),
//                         child: Text(
//                           "${controller.selectedProvider.value.fullName.capitalizeFirst}",
//                           style: mainStyle(
//                             fontSize: 36,
//                             fontColor: mainColor,
//                           ),
//                           textAlign: TextAlign.center,
//                         ),
//                       ),
//                       SizedBox(
//                         height: 24,
//                       ),
//                       Row(
//                         mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                         children: [
//                           Container(
//                             child: Row(
//                               children: [
//                                 Container(
//                                   margin: EdgeInsets.all(16),
//                                   height: 75,
//                                   width: 75,
//                                   decoration: BoxDecoration(
//                                     image: DecorationImage(
//                                         image: Image.asset(
//                                                 "assets/icons/${controller.selectedProvider.value.profession.toLowerCase()}.png")
//                                             .image),
//                                   ),
//                                 ),
//                                 Text(
//                                   "${controller.selectedProvider.value.profession.capitalizeFirst}",
//                                   style: mainStyle(
//                                       fontSize: 36, fontColor: sColor1),
//                                 )
//                               ],
//                             ),
//                           ),
//                         ],
//                       ),
//                       Padding(
//                         padding: const EdgeInsets.only(left: 16, right: 16),
//                         child: Text(
//                           "Price :",
//                           style: mainStyle(fontSize: 36),
//                         ),
//                       ),
//                       Padding(
//                         padding: const EdgeInsets.only(
//                           left: 16,
//                           right: 16,
//                           bottom: 16,
//                         ),
//                         child: Text(
//                           "${controller.selectedProvider.value.priceRange.substring(1, controller.selectedProvider.value.priceRange.length - 1)} L.L",
//                           style: montserratStyle(fontSize: 24),
//                           textAlign: TextAlign.end,
//                         ),
//                       ),
//                       Padding(
//                         padding: const EdgeInsets.only(left: 16, right: 16),
//                         child: Text(
//                           "Contact :",
//                           style: mainStyle(fontSize: 36),
//                         ),
//                       ),
//                       GestureDetector(
//                         onTap: () async {
// var whatsappUrl =
//     "whatsapp://send?phone=${controller.selectedProvider.value.phoneNumber}";
// launch(whatsappUrl);
//                         },
//                         child: Padding(
//                           padding: const EdgeInsets.only(left: 16, right: 16),
//                           child: Text(
//                             "${controller.selectedProvider.value.phoneNumber}",
//                             style: montserratStyle(
//                                 fontSize: 24, fontColor: Colors.blue),
//                             textAlign: TextAlign.end,
//                           ),
//                         ),
//                       ),
//                       SizedBox(
//                         height: 24,
//                       ),
//                     ],
//                   )
