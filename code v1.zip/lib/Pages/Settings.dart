import 'package:day_night_switcher/day_night_switcher.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:locateme/Configuration/FontStyles.dart';
import 'package:locateme/Configuration/Pallette.dart';
import 'package:locateme/Services/LocalizationServices.dart';
import 'package:locateme/Services/ThemServices.dart';
import 'package:locateme/Controllers/SettingsController.dart';
import 'package:rflutter_alert/rflutter_alert.dart';

class SettingsView extends StatelessWidget {
  SettingsView();

  final SettingsController settingsController = Get.put(SettingsController());

  @override
  Widget build(BuildContext context) {
    return Obx(
      () => Container(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(height: Get.height * 0.05),
            Padding(
              padding: const EdgeInsets.fromLTRB(16.0, 0, 16, 0),
              child: ListTile(
                title: Text(
                  "appLanguage".tr,
                  style: mainStyle(
                    fontColor: context.theme.primaryColor,
                    fontSize: 24,
                  ),
                ),
                subtitle: Text(
                  getLanguage().tr,
                  style: mainStyle(
                    fontColor: context.theme.primaryColor,
                    fontSize: 24,
                  ),
                ),
                trailing: Icon(
                  Icons.language,
                  size: 36,
                  color: context.theme.primaryColor,
                ),
                onTap: () {
                  Alert(
                    context: context,
                    style: AlertStyle(),
                    type: AlertType.info,
                    title: "appLanguage".tr,
                    desc: "appLangDesc".tr,
                    buttons: [
                      DialogButton(
                        child: Text(
                          "cancel".tr,
                          style: TextStyle(color: Colors.white, fontSize: 20),
                        ),
                        onPressed: () {
                          Get.back();
                        },
                        color: Colors.red,
                        radius: BorderRadius.circular(24.0),
                      ),
                      DialogButton(
                        child: Text(
                          getOppLanguage().tr,
                          style: TextStyle(color: Colors.white, fontSize: 20),
                        ),
                        onPressed: () {
                          LocalizationService().changeLocale(getOppLanguage());
                          Get.back();
                        },
                        color: Color.fromRGBO(0, 179, 134, 1.0),
                        radius: BorderRadius.circular(24.0),
                      ),
                    ],
                  ).show();
                },
              ),
            ),
            Divider(
              color: ThemeService().isDarkMode() ? Colors.white : mainColor,
              thickness: 1,
              indent: Get.width * 0.1,
              endIndent: Get.width * 0.1,
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(16.0, 0, 16, 0),
              child: ListTile(
                title: Text(
                  "darkMode".tr,
                  style: mainStyle(fontColor: context.theme.primaryColor),
                ),
                subtitle: Text(
                  isDarkModeOn(),
                  style: mainStyle(
                    fontColor: context.theme.primaryColor,
                    fontSize: 24,
                  ),
                ),
                trailing: DayNightSwitcher(
                  onStateChanged: (value) {
                    ThemeService().switchTheme();
                    // print(value);
                  },
                  isDarkModeEnabled: ThemeService().isDarkMode(),
                ),
                // onTap: ThemeService().switchTheme,
              ),
            ),
            Divider(
              color: ThemeService().isDarkMode() ? Colors.white : mainColor,
              thickness: 1,
              indent: Get.width * 0.1,
              endIndent: Get.width * 0.1,
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(32.0, 32, 32, 0),
              child: Text(
                "HomePageView".tr,
                textAlign: TextAlign.start,
                style: mainStyle(
                  fontColor: context.theme.primaryColor,
                  fontSize: 24,
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(16),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  Column(
                    children: [
                      Container(
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: Colors.grey[350],
                        ),
                        height: 40,
                        width: 40,
                        child: Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: AnimatedContainer(
                            height: 25,
                            width: 25,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color:
                                  settingsController.optionSelected.value == 0
                                      ? context.theme.primaryColor
                                      : Colors.grey[350],
                            ),
                            duration: Duration(
                              milliseconds: 500,
                            ),
                          ),
                        ),
                      ),
                      SizedBox(
                        height: 20,
                      ),
                      GestureDetector(
                        onTap: () {
                          settingsController.changeOption(0);
                        },
                        child: AnimatedOpacity(
                          duration: Duration(milliseconds: 500),
                          opacity: settingsController.optionSelected.value == 0
                              ? 1
                              : 0.2,
                          child: Container(
                            height: 150,
                            width: 150,
                            decoration: BoxDecoration(
                              color: mainColor.withOpacity(0.85),
                              borderRadius: BorderRadius.circular(25),
                              image: DecorationImage(
                                image: AssetImage(
                                  "assets/mapStyles/map.png",
                                ),
                                fit: BoxFit.cover,
                                colorFilter: ColorFilter.mode(
                                  Colors.white,
                                  BlendMode.xor,
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                      SizedBox(
                        height: 20,
                      ),
                      Text(
                        "mapView".tr,
                        style: mainStyle(
                          fontColor: context.theme.primaryColor,
                          fontSize: 24,
                        ),
                      )
                    ],
                  ),
                  Column(
                    children: [
                      Container(
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: Colors.grey[350],
                        ),
                        height: 40,
                        width: 40,
                        child: Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: AnimatedContainer(
                            height: 25,
                            width: 25,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color:
                                  settingsController.optionSelected.value == 1
                                      ? context.theme.primaryColor
                                      : Colors.grey[350],
                            ),
                            duration: Duration(
                              milliseconds: 500,
                            ),
                          ),
                        ),
                      ),
                      SizedBox(
                        height: 20,
                      ),
                      GestureDetector(
                        onTap: () {
                          settingsController.changeOption(1);
                        },
                        child: AnimatedOpacity(
                          duration: Duration(milliseconds: 500),
                          opacity: settingsController.optionSelected.value != 0
                              ? 1
                              : 0.2,
                          child: Container(
                            clipBehavior: Clip.hardEdge,
                            height: 150,
                            width: 150,
                            decoration: BoxDecoration(
                              color: Colors.grey[350],
                              borderRadius: BorderRadius.circular(25),
                            ),
                            child: ListView.builder(
                              controller:
                                  settingsController.smallListController,
                              itemCount: 4,
                              itemBuilder: (context, index) => Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: Container(
                                  height: 150 / 4,
                                  width: 150 * 0.85,
                                  decoration: BoxDecoration(
                                    color: index % 2 == 0
                                        ? Colors.white
                                        : mainColor,
                                    borderRadius: BorderRadius.circular(12),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                      SizedBox(
                        height: 20,
                      ),
                      Text(
                        "listView".tr,
                        style: mainStyle(
                          fontColor: context.theme.primaryColor,
                          fontSize: 24,
                        ),
                      )
                    ],
                  )
                ],
              ),
            )
          ],
        ),
      ),
    );
  }

  String getLanguage() {
    return Get.locale.languageCode == "en" ? "English" : "Arabic";
  }

  String getOppLanguage() {
    return Get.locale.languageCode != "en" ? "English" : "Arabic";
  }

  String isDarkModeOn() {
    return ThemeService().isDarkMode() ? "On" : "Off";
  }
}
