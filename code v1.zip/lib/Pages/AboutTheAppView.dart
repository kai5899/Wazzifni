import 'package:flutter/material.dart';

class AboutTheAppView extends StatelessWidget {
  const AboutTheAppView({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      child: Center(child: Text("About the app view"),),
    );
  }
}