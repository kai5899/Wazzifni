import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:locateme/Configuration/FontStyles.dart';

class RegUserJobsView extends StatelessWidget {
  const RegUserJobsView({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      child: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Image.asset(
              "assets/icons/consult.png",
              height: Get.height * 0.25,
              width: Get.height * 0.25,
            ),
            SizedBox(
              height: 20,
            ),
            Text(
              "Will Be Added SoOn ! ".camelCase,
              style: mainStyle(
                fontSize: 48,
                fontColor: Colors.red,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
