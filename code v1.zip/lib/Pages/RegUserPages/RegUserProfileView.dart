import 'dart:math';

import 'package:firebase_storage/firebase_storage.dart';
import 'package:locateme/Configuration/Constants.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:locateme/Configuration/FontStyles.dart';
import 'package:locateme/Configuration/Pallette.dart';
import 'package:locateme/Controllers/AuthController.dart';
import 'package:locateme/Controllers/RegUserProfileController.dart';
import 'package:locateme/Widgets/CustomInputField.dart';
import 'package:rflutter_alert/rflutter_alert.dart';

class RegUserProfileView extends StatelessWidget {
  RegUserProfileView();
  final AuthController authController = Get.put(AuthController());
  final RegUserProfileController _profileController =
      Get.put(RegUserProfileController());

  @override
  Widget build(BuildContext context) {
    return Obx(
      () => Container(
        child: SingleChildScrollView(
          child: Column(
            children: [
              GestureDetector(
                onTap: () {
                  _profileController.getImage(
                      userID: authController.localUser["uid"],
                      authController: authController);
                },
                child: Container(
                    height: Get.height * 0.25,
                    width: Get.height * 0.25,
                    decoration: BoxDecoration(
                      color: mainColor,
                      shape: BoxShape.circle,
                    ),
                    child: Stack(
                      children: [
                        _profileController.uploadTask.value == null
                            ? Container()
                            : StreamBuilder(
                                stream: _profileController
                                    .uploadTask.value.snapshotEvents,
                                builder: (BuildContext context,
                                    AsyncSnapshot snapshot) {
                                  Widget indicator;
                                  if (snapshot.hasData) {
                                    final TaskSnapshot snap = snapshot.data;
                                    indicator = CircularProgressIndicator(
                                      strokeWidth: 7,
                                      value: snap.bytesTransferred /
                                          snap.totalBytes,
                                      backgroundColor: mainColor,
                                      valueColor: AlwaysStoppedAnimation<Color>(
                                          sColor1),
                                    );
                                    return Container(
                                      height: Get.height * 0.25,
                                      width: Get.height * 0.25,
                                      decoration: BoxDecoration(
                                        color: mainColor,
                                        shape: BoxShape.circle,
                                      ),
                                      child: indicator,
                                    );
                                  } else {
                                    indicator = const Text('Starting...');
                                    return ListTile(
                                      title: indicator,
                                    );
                                  }
                                },
                              ),
                        authController.localUser["photoUrl"] == "none" ||
                                authController.localUser["photoUrl"] == null
                            ? Center(
                                child: Text(
                                  authController.localUser["fullName"][0],
                                  style: mainStyle(
                                    fontColor: Colors.white,
                                    fontSize: Get.height * 0.2,
                                  ),
                                ),
                              )
                            : Center(
                                child: Container(
                                  height: Get.height * 0.24,
                                  width: Get.height * 0.24,
                                  decoration: BoxDecoration(
                                      // color: sColor3,
                                      shape: BoxShape.circle,
                                      image: DecorationImage(
                                        image: Image.network(
                                          authController.localUser["photoUrl"],
                                          key: ValueKey(
                                              new Random().nextInt(100)),
                                        ).image,
                                        fit: BoxFit.cover,
                                      )),
                                ),
                              ),
                      ],
                    )),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(16.0, 16, 16, 16),
                child: Center(
                  child: Text(
                    authController.localUser["type"].toString().tr,
                    style: mainStyle(
                      fontColor: sColor3,
                      fontSize: 36,
                    ),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(left: 16, top: 16),
                child: ListTile(
                  title: Text(
                    "fullName".tr,
                    style: mainStyle(fontColor: context.theme.primaryColor),
                  ),
                  subtitle: Text(
                    authController.localUser["fullName"].toString(),
                    style: mainStyle(
                      fontSize: 36,
                      fontColor: mainColor,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  trailing: Container(
                    height: 50,
                    width: 50,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(12),
                      color: mainColor,
                    ),
                    child: Center(
                      child: Icon(
                        Icons.edit,
                        color: Colors.white,
                        size: 30,
                      ),
                    ),
                  ),
                  onTap: () {
                    Alert(
                        context: context,
                        closeFunction: () {
                          Get.back();
                        },
                        title: "Edit Name",
                        style: AlertStyle(
                          animationType: AnimationType.grow,
                          animationDuration: Duration(milliseconds: 500),
                          titleStyle: mainStyle(fontColor: Colors.red),
                        ),
                        content: Column(
                          children: <Widget>[
                            FieldEdited(
                              isPassword: false,
                              label: "fullName".tr,
                              type: TextInputType.name,
                              textColor: mainColor,
                              controller: _profileController.nameController,
                              padding: EdgeInsets.zero,
                            ),
                          ],
                        ),
                        buttons: [
                          DialogButton(
                            color: Colors.white,
                            onPressed: () => Get.back(),
                            child: Text(
                              "cancel".tr,
                              style: mainStyle(fontSize: 24),
                            ),
                          ),
                          DialogButton(
                            color: sColor3,
                            onPressed: () {
                              authController.updateRegUserName(
                                  _profileController.nameController.text);
                              Get.back();
                            },
                            child: Text(
                              "save".tr,
                              style: mainStyle(
                                  fontSize: 24, fontColor: Colors.white),
                            ),
                          )
                        ]).show();
                    // authController.updateRegUserName("wawa");
                  },
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(left: 16),
                child: ListTile(
                  onTap: () {
                    Alert(
                        context: context,
                        closeFunction: () {
                          Get.back();
                        },
                        title: "Edit BirthDay",
                        style: AlertStyle(
                          animationType: AnimationType.grow,
                          animationDuration: Duration(milliseconds: 500),
                          titleStyle: mainStyle(fontColor: Colors.red),
                        ),
                        content: Column(
                          children: <Widget>[
                            IconButton(
                              icon: Icon(
                                Icons.calendar_today,
                              ),
                              onPressed: () {
                                _profileController.pickDateDialog(context);
                              },
                            )
                          ],
                        ),
                        buttons: [
                          DialogButton(
                            color: Colors.white,
                            onPressed: () => Get.back(),
                            child: Text(
                              "cancel".tr,
                              style: mainStyle(fontSize: 24),
                            ),
                          ),
                          DialogButton(
                            color: sColor3,
                            onPressed: () {
                              authController.updateRegUserBirthDay(
                                  _profileController.selectedDate.value.day
                                          .toString() +
                                      "/" +
                                      _profileController
                                          .selectedDate.value.month
                                          .toString() +
                                      "/" +
                                      _profileController.selectedDate.value.year
                                          .toString());
                              Get.back();
                            },
                            child: Text(
                              "save".tr,
                              style: mainStyle(
                                  fontSize: 24, fontColor: Colors.white),
                            ),
                          )
                        ]).show();
                  },
                  title: Text(
                    "birthDay".tr,
                    style: mainStyle(fontColor: context.theme.primaryColor),
                  ),
                  subtitle: Text(
                    authController.localUser["birthDay"]
                        .toString()
                        .capitalizeFirst,
                    style: mainStyle(
                      fontSize: 24,
                      fontColor: mainColor,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  trailing: Container(
                    height: 50,
                    width: 50,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(12),
                      color: mainColor,
                    ),
                    child: Center(
                      child: Icon(
                        Icons.edit,
                        color: Colors.white,
                        size: 30,
                      ),
                    ),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(left: 16),
                child: ListTile(
                  title: Text(
                    "zodiac".tr,
                    style: mainStyle(fontColor: context.theme.primaryColor),
                  ),
                  subtitle: Text(
                    getZodicaSign(
                      days: int.parse(authController.localUser["birthDay"]
                          .toString()
                          .split("/")[0]),
                      months: int.parse(authController.localUser["birthDay"]
                          .toString()
                          .split("/")[1]),
                    ),
                    style: mainStyle(fontColor: mainColor, fontSize: 36),
                  ),
                  trailing: Container(
                    height: 50,
                    width: 50,
                    decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        image: DecorationImage(
                            image: Image.asset("assets/zodiac/${getZodicaSign(
                          days: int.parse(authController.localUser["birthDay"]
                              .toString()
                              .split("/")[0]),
                          months: int.parse(authController.localUser["birthDay"]
                              .toString()
                              .split("/")[1]),
                        ).toString().toLowerCase()}.png")
                                .image)),
                  ),
                  onTap: () {},
                ),
              )
            ],
          ),
        ),
      ),
    );
  }

  bool isRunningState(TaskSnapshot snap) {
    return snap.state.toString() == "TaskState.running";
  }
}
